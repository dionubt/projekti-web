<?php
// Include the database connection file
require_once 'database.php';

// Replace these with your actual database credentials
$servername = "localhost";
$username = "your_mysql_username";
$password = "your_mysql_password";
$database = "your_database_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

